#!/bin/bash
python flashcart-writer.py games-image.bin

